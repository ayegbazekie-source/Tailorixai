import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { 
  ArrowLeft,
  Upload,
  Camera,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  X,
  Image as ImageIcon,
  Loader2,
  Ruler,
  Scissors,
  Target,
  Crown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CameraCapture from '../components/CameraCapture';
import CreditDisplay from '../components/CreditDisplay';
import UpgradeModal from '../components/UpgradeModal';
import { useCreditSystem } from '@/components/useCreditSystem';
import AILoadingNotice from '@/components/AILoadingNotice';
import RateReviewModal from '@/components/RateReviewModal';
import { useRandomReviewPrompt } from '@/hooks/useRandomReviewPrompt';

export default function ImageAnalysis() {
  const navigate = useNavigate();
  const {
    credits, loading,
    isPremium, hasCredits, deductCredit
  } = useCreditSystem('analysis');
  const [image, setImage] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [analysisType, setAnalysisType] = useState('fitting');
  const [user, setUser] = useState(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const { reviewTrigger, triggerReview, resetReviewTrigger } = useRandomReviewPrompt();
  const fileInputRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Removed auto-analyze on tab change — user must click the Analyze button

  const handleFileSelect = async (file) => {
    if (!file) return;

    setImage(file);
    setUploading(true);
    setAnalysis(null);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setImageUrl(file_url);
    } catch (e) {
      console.error(e);
    }
    setUploading(false);
  };

  const analyzeImage = async () => {
    if (!imageUrl) return;

    // Check if user has credits
    if (!hasCredits) {
      setShowUpgradeModal(true);
      return;
    }

    // Deduct credit
    if (!isPremium) {
      const result = await deductCredit();
      if (!result?.success) return;
    }

    setAnalyzing(true);
    try {
      const illustrationEyeDirective = `
══ "ILLUSTRATION EYE" GARMENT ANALYSIS DIRECTIVE ══

━━━ PHASE 1: INTERNAL RECONSTRUCTION (The "Reference Blueprint") ━━━
This is your MANDATORY first step — complete it before looking at any fitting issues.

STEP 1 — STYLE DETECTION:
Identify the exact garment family from this list:
  MALE: Traditional Agbada | Senator Kaftan | Corporate Shirt/Suit | Vest | Trousers | Shorts
  FEMALE: Corset Top/Gown | Princess Cut Gown | Peplum Gown | Flared Gown | Fitted Gown | Maxi Gown | Buba/Wrapper | Corporate Blouse | Skirt | Trousers | Shorts

STEP 2 — INTERNAL ILLUSTRATION (Your "True North"):
Using your knowledge of that style, mentally construct a perfect reference illustration of this garment on a standard human frame with a similar body structure to the person in the photo.
This blueprint represents 100% technical accuracy — perfect seam lines, correct dart points, proper ease distribution.

STEP 3 — LANDMARK MAPPING ON BLUEPRINT:
On your internal blueprint, pre-map the EXACT correct coordinates for:
  • Shoulder Tips (Acromion) — where the sleeve head should end
  • Suprasternal Notch (Neck base) — where the neckline/collar should sit
  • Apex / Bust Points — where darts/princess seams must point (female only)
  • Natural Waist — where waist joinings must land
  • High Hip — ~9cm below natural waist
  • Knee — for length reference (trousers, midi skirts)

━━━ PHASE 2: PHOTO ANALYSIS & COMPARATIVE SCORING (The "Comparison Eye") ━━━
Now compare the uploaded photo against your internal blueprint, zone by zone.

ZONE 1 — NECK & SHOULDERS (vs. Blueprint):
  • Does the shoulder seam land exactly at the Shoulder Tip on your blueprint? If not, state the estimated distance (e.g., "The shoulder seam is sitting ~1.5cm inward from the shoulder tip").
  • For collared styles: Is there "Gaposis" (collar standing away from neck) compared to how the collar lies on the blueprint?
  • AGBADA EXCEPTION: Skip shoulder seam rules entirely. Instead, compare the embroidery center balance and wing drape symmetry against your Agbada blueprint.

ZONE 2 — SLEEVES & ARMHOLES (vs. Blueprint):
  • Is the Sleeve Head (top curve of sleeve) smooth on the photo vs. the blueprint? Flag any puckering.
  • Is the armhole depth correct? Compare to blueprint — too deep exposes undergarments, too tight creates pulling lines toward the chest.

ZONE 3 — JOININGS & CHEST/BUST SHAPING (vs. Blueprint):
  • FEMALE: Do the darts/princess seams in the photo point directly toward the Apex landmark on your blueprint? If they miss by even 1cm, flag it: "The dart is pointing approximately 1.5cm above your bust point — it needs to swing down slightly."
  • MALE: Is the chest pocket perfectly horizontal vs. blueprint? Is the placket (button line) perfectly vertical?

ZONE 4 — LOWER BODY — WAIST TO HEM (vs. Blueprint):
  • TROUSERS/SHORTS: Are there "Whiskers" (tension lines fanning from the crotch) that wouldn't appear on the blueprint? This means the Rise (crotch length) is too short.
  • SKIRTS/GOWNS: Is the hem level on all sides vs. blueprint? Any dip = deduction.
  • WAIST JOINING: Does it sit at the Natural Waist landmark on your blueprint? State exact distance if off.

━━━ MOVEMENT VS. ERROR FILTER (Apply BEFORE scoring) ━━━
After the comparison, ask: Would this issue exist on the blueprint if the person were standing perfectly still?
  ✓ YES → It is a TECHNICAL FAULT. Deduct points and explain the fix.
  ✗ NO (caused by posture, sitting, leaning, hands in pockets) → It is a WEARER VARIABLE. Do NOT deduct. Do NOT flag it.
PERFECT CONSTRUCTION RULE: If the photo's construction geometry matches the blueprint and only movement folds are present → award 100% and say: "This garment is perfectly constructed! The small folds you see are just the fabric moving with you. 100% Professional Quality."

━━━ ENCOURAGEMENT SCORING ━━━
100%  → All four zones match the blueprint. Every landmark hit correctly. Natural folds are fine.
90–99 → Blueprint match excellent but 1 zone has a very small deviation (e.g., shoulder 0.5cm off tip).
75–89 → Blueprint match good but 1–2 clear technical faults visible even standing still.
55–74 → Multiple zones deviate from blueprint OR 2+ landmark misses.
35–54 → Significant cutting or construction errors — silhouette diverges from blueprint.
0–34  → Photo construction does not resemble the blueprint at all — major errors throughout.
SCORE MUST MATCH FAULTS LISTED: Zero real faults = 90+ score. Three major faults = below 65.

━━━ PHASE 3: BEGINNER VERDICT — WORKROOM ENGLISH ━━━
Translate ALL technical findings into warm, simple, friendly language. Teach while correcting.
  • "Extra space for movement" (NOT "ease")
  • "A piece added to give more room" (NOT "gusset")
  • "Front piece" (NOT "anterior bodice segment")
  • "Trouser / Pants" (NOT "bifurcated garment")
  • Always state exact distances: "The waist joining sits 2cm above your natural waist" not "the waist is elevated."
  • If tight: "This area is too tight — the fabric is pulling because there isn't enough room."
  • If loose: "There's extra fabric bunching here — it needs to be taken in."

MANDATORY ENCOURAGEMENT CLOSING — Every analysis MUST end professional_notes with a warm, specific tip:
  If issues found: "You've done a great job on the [specific positive]! Just [specific fix] next time — and you'll hit a perfect 100%."
  If flawless: "This is beautifully constructed from top to bottom. Every joining is hitting its mark — this is professional-quality work. Keep it up!"
`;

      const prompts = {
        fitting: `You are Tailorix AI — a master garment analyst with an "Illustration Eye." You internally reconstruct a perfect reference blueprint of every garment before scoring, and compare the photo against that blueprint zone by zone.

${illustrationEyeDirective}

Run ALL THREE PHASES in order:
1. Build your internal Reference Blueprint (Style Detection → Internal Illustration → Landmark Mapping).
2. Compare the photo against the blueprint across all four zones (Neck/Shoulders, Sleeves/Armholes, Joinings/Chest, Lower Body). Apply the Movement vs. Error filter.
3. Deliver your verdict in warm Workroom English with the mandatory encouragement closing.`,

        seams: `You are Tailorix AI — a master sewing coach with an "Illustration Eye." You build a perfect internal blueprint of the garment's construction before checking seam quality.

${illustrationEyeDirective}
Note: fit_score here measures CONSTRUCTION QUALITY — how closely the seams, stitching, and joins match what the internal blueprint demands.

Run ALL THREE PHASES:
1. Build your Reference Blueprint — what should the seams look like for this exact style?
2. Compare seam quality across all four zones against the blueprint:
   - Zone 1: Does the collar/neckline join lie as flat as the blueprint?
   - Zone 2: Is the sleeve head as smooth as the blueprint (no puckering)?
   - Zone 3: Are panel joins and dart stitching as clean as the blueprint?
   - Zone 4: Is the hem as level as the blueprint's hem line?
   Apply the Movement vs. Error filter — only flag seams that would be wrong even if the garment were laid flat.
3. Deliver your verdict in warm Workroom English with the mandatory encouragement closing.`,

        general: `You are Tailorix AI — a friendly garment expert with an "Illustration Eye." You create an internal reference blueprint of every garment before giving your overview.

${illustrationEyeDirective}

Run ALL THREE PHASES:
1. Build your Reference Blueprint — identify the style and map all landmarks.
2. Give a quick four-zone overview against the blueprint (Shoulders → Sleeves → Joinings → Hem). Note what matches and what deviates.
3. Deliver a complete beginner-friendly overview covering:
   - Garment type and style in plain English.
   - Fabric appearance (stretchy, stiff, flowy).
   - Four-zone blueprint comparison verdict.
   - One style tip and one fabric care tip.
   End with the mandatory encouragement closing.`
      };

      const schemas = {
        fitting: {
          type: "object",
          properties: {
            garment_type: { type: "string" },
            overall_assessment: { type: "string" },
            fit_score: { type: "number" },
            fitting_problems: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  problem: { type: "string" },
                  severity: { type: "string", enum: ["minor", "moderate", "major"] },
                  visual_indicator: { type: "string" },
                  correction: { type: "string" },
                  measurement_adjustment: { type: "string" }
                }
              }
            },
            alteration_steps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  step_number: { type: "number" },
                  action: { type: "string" },
                  details: { type: "string" },
                  tools_needed: { type: "string" },
                  difficulty: { type: "string", enum: ["easy", "intermediate", "advanced"] }
                }
              }
            },
            positive_aspects: { type: "array", items: { type: "string" } },
            preventive_advice: { type: "array", items: { type: "string" } },
            professional_notes: { type: "string" }
          }
        },
        seams: {
          type: "object",
          properties: {
            garment_type: { type: "string" },
            overall_assessment: { type: "string" },
            fit_score: { type: "number" },
            seam_zones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  zone: { type: "string" },
                  verdict: { type: "string" },
                  quality: { type: "string", enum: ["excellent", "good", "needs_work", "poor"] },
                  issue: { type: "string" },
                  fix: { type: "string" }
                }
              }
            },
            stitching_tips: { type: "array", items: { type: "string" } },
            positive_aspects: { type: "array", items: { type: "string" } },
            professional_notes: { type: "string" }
          }
        },
        general: {
          type: "object",
          properties: {
            garment_type: { type: "string" },
            overall_assessment: { type: "string" },
            fit_score: { type: "number" },
            fabric_assessment: { type: "string" },
            zone_overview: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  zone: { type: "string" },
                  verdict: { type: "string" },
                  status: { type: "string", enum: ["pass", "minor_issue", "needs_work"] }
                }
              }
            },
            style_tip: { type: "string" },
            fabric_care_tip: { type: "string" },
            positive_aspects: { type: "array", items: { type: "string" } },
            professional_notes: { type: "string" }
          }
        }
      };

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompts[analysisType],
        file_urls: [imageUrl],
        response_json_schema: schemas[analysisType]
      });

      setAnalysis(response);
      triggerReview();
    } catch (e) {
      console.error(e);
    }
    setAnalyzing(false);
  };

  const clearImage = () => {
    setImage(null);
    setImageUrl(null);
    setAnalysis(null);
  };

  const severityColors = {
    minor: 'bg-amber-100 text-amber-700 border-amber-200',
    moderate: 'bg-orange-100 text-orange-700 border-orange-200',
    major: 'bg-rose-100 text-rose-700 border-rose-200'
  };

  const difficultyColors = {
    easy: 'bg-emerald-100 text-emerald-700',
    intermediate: 'bg-amber-100 text-amber-700',
    advanced: 'bg-rose-100 text-rose-700'
  };

  const isPremiumTheme = isPremium;

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isPremium ? 'bg-gradient-to-br from-[#121212] via-[#1a1a1a] to-[#1E1E1E]' : 'bg-gradient-to-br from-slate-50 to-slate-100'}`}>
        <div className="text-center">
          <Loader2 className={`w-12 h-12 animate-spin mx-auto mb-4 ${isPremium ? 'text-amber-400' : 'text-violet-500'}`} />
          <p className={isPremium ? 'text-amber-200/80' : 'text-slate-600'}>Loading analysis...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isPremiumTheme ? 'bg-gradient-to-br from-[#121212] via-[#1a1a1a] to-[#1E1E1E]' : 'bg-gradient-to-br from-[var(--gradient-start)] via-[var(--gradient-middle)] to-[var(--gradient-end)]'}`}>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => navigate(-1)} className={`mb-6 -ml-4 hidden md:flex ${isPremiumTheme ? 'text-amber-200/60 hover:text-amber-300' : 'text-[var(--text-secondary)]'}`}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-4 ${isPremiumTheme ? 'bg-gradient-to-r from-amber-900/30 to-yellow-900/30 border border-amber-500/30 text-amber-400' : 'bg-violet-50 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400'}`}>
              <Camera className="w-4 h-4" />
              {isPremiumTheme && <Crown className="w-4 h-4" />}
              Garment Analysis {isPremiumTheme && 'Pro'}
            </div>
            <div className="flex items-center justify-between mb-3">
              <h1 className={`text-2xl md:text-3xl font-light tracking-tight ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                <span className={`font-semibold ${isPremiumTheme ? 'bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent' : ''}`}>Garment Analysis</span>
              </h1>
              <CreditDisplay credits={credits} featureName="Analysis" isPremium={isPremium} />
            </div>
            <p className={`text-base font-light ${isPremiumTheme ? 'text-amber-200/80' : 'text-[var(--text-secondary)]'}`}>
              Upload garment photos for expert fitting diagnosis, alteration guidance, and professional tailoring advice.
            </p>
            <AILoadingNotice dark={isPremiumTheme} className="mt-4" />
          </motion.div>
        </div>

        {/* Analysis Type Tabs */}
        <Tabs value={analysisType} onValueChange={setAnalysisType} className="mb-8">
          <TabsList className={`grid grid-cols-3 w-full max-w-md ${isPremiumTheme ? 'bg-slate-800/50 border border-amber-500/20' : ''}`}>
            <TabsTrigger value="fitting" className={`flex items-center gap-2 ${isPremiumTheme ? 'data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-yellow-500 data-[state=active]:text-slate-900' : ''}`}>
              <Target className="w-4 h-4" />
              Fitting Issues
            </TabsTrigger>
            <TabsTrigger value="seams" className={`flex items-center gap-2 ${isPremiumTheme ? 'data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-yellow-500 data-[state=active]:text-slate-900' : ''}`}>
              <Scissors className="w-4 h-4" />
              Seam Quality
            </TabsTrigger>
            <TabsTrigger value="general" className={`flex items-center gap-2 ${isPremiumTheme ? 'data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-yellow-500 data-[state=active]:text-slate-900' : ''}`}>
              <Ruler className="w-4 h-4" />
              General
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div 
              className={`
                relative rounded-3xl border-2 border-dashed transition-all overflow-hidden
                ${!image ? (isPremiumTheme ? 'border-amber-500/30 bg-gradient-to-br from-slate-800 to-slate-900' : 'border-[var(--border-primary)] bg-[var(--card-bg)]') : (isPremiumTheme ? 'border-amber-500 bg-amber-900/20' : 'border-violet-500 bg-violet-50 dark:bg-violet-900/20')}
              `}
            >
              {!image ? (
                <div className="p-8 text-center">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${isPremiumTheme ? 'bg-amber-900/30' : 'bg-violet-100 dark:bg-violet-900/30'}`}>
                    <Upload className={`w-8 h-8 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                  </div>
                  <h3 className={`text-lg font-semibold mb-2 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                    Upload Garment Photo
                  </h3>
                  <p className={`text-sm mb-3 ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>
                    For best results, upload clear photos showing:
                  </p>
                  <ul className={`text-xs space-y-1 mb-4 ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-secondary)]'}`}>
                    <li>• Full garment on body or dress form</li>
                    <li>• Problem areas close-up</li>
                    <li>• Seams, darts, or fitting issues</li>
                  </ul>
                  <CameraCapture 
                    onCapture={handleFileSelect}
                    onFileSelect={handleFileSelect}
                  />
                </div>
              ) : (
                <div className="relative">
                  {uploading && (
                    <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-10">
                      <div className="text-center">
                        <Loader2 className="w-8 h-8 animate-spin text-violet-500 mx-auto mb-2" />
                        <p className="text-slate-600">Uploading...</p>
                      </div>
                    </div>
                  )}
                  
                  <img 
                    src={imageUrl || URL.createObjectURL(image)} 
                    alt="Uploaded garment"
                    className="w-full h-auto max-h-[500px] object-contain"
                  />
                  
                  <Button
                    variant="secondary"
                    size="icon"
                    className="absolute top-4 right-4 rounded-full bg-white/80 hover:bg-white"
                    onClick={(e) => { e.stopPropagation(); clearImage(); }}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>

            {image && !analysis && (
              <>
                {!hasCredits ? (
                  <Button
                    onClick={() => setShowUpgradeModal(true)}
                    className="w-full mt-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 rounded-2xl py-6 text-lg"
                  >
                    <Sparkles className="w-5 h-5 mr-2" />
                    Out of Credits — Upgrade to Pro
                  </Button>
                ) : (
                  <Button
                    onClick={analyzeImage}
                    disabled={uploading || analyzing}
                    className={`w-full mt-4 rounded-xl py-3 text-base ${isPremiumTheme ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-900 font-bold shadow-lg shadow-amber-500/30' : 'bg-violet-600 hover:bg-violet-700'}`}
                  >
                    {analyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Analyze {analysisType === 'fitting' ? 'Fitting' : analysisType === 'seams' ? 'Seams' : 'Garment'}
                      </>
                    )}
                  </Button>
                )}
              </>
            )}
          </motion.div>

          {/* Analysis Results */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <AnimatePresence mode="wait">
              {analyzing && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className={`rounded-3xl p-8 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isPremiumTheme ? 'bg-amber-900/30' : 'bg-violet-100 dark:bg-violet-900/30'}`}>
                      <Loader2 className={`w-6 h-6 animate-spin ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                    </div>
                    <div>
                      <h3 className={`font-semibold ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>Tailorix AI is Analyzing</h3>
                      <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>Professional assessment in progress...</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {['Building internal reference blueprint for this style...', 'Mapping body landmarks (shoulders, apex, waist, hem)...', 'Comparing photo to blueprint across all four zones...', 'Filtering posture folds · calculating encouragement score...'].map((step, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full animate-pulse ${isPremiumTheme ? 'bg-amber-400' : 'bg-violet-400'}`} />
                        <span className={`text-sm ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-secondary)]'}`}>{step}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {analysis && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6 max-h-[calc(100vh-300px)] overflow-y-auto pr-2"
                >
                  {/* ── Shared Score Header ── */}
                  <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className={`text-sm ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-secondary)]'}`}>Identified</span>
                        <h3 className={`text-xl font-semibold ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>{analysis.garment_type}</h3>
                      </div>
                      <div className="text-right">
                        <span className={`text-sm ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-secondary)]'}`}>
                          {analysisType === 'seams' ? 'Quality Score' : analysisType === 'general' ? 'Fit Score' : 'Fit Score'}
                        </span>
                        <div className={`text-3xl font-bold ${isPremiumTheme ? 'text-amber-400' : 'text-violet-600'}`}>{analysis.fit_score}%</div>
                      </div>
                    </div>
                    <p className={isPremiumTheme ? 'text-amber-200/70 mb-4' : 'text-[var(--text-secondary)] mb-4'}>{analysis.overall_assessment}</p>
                    <div className={`p-4 rounded-xl border ${isPremiumTheme ? 'bg-amber-900/20 border-amber-500/30' : 'bg-violet-50 dark:bg-violet-900/20 border-violet-100 dark:border-violet-800'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <p className={`text-sm font-medium ${isPremiumTheme ? 'text-amber-300' : 'text-violet-900 dark:text-violet-300'}`}>
                          {analysis.fit_score >= 90 ? 'Excellent' : analysis.fit_score >= 75 ? 'Good' : analysis.fit_score >= 55 ? 'Needs Work' : analysis.fit_score >= 35 ? 'Significant Issues' : 'Poor'}
                        </p>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${analysis.fit_score >= 75 ? 'bg-emerald-100 text-emerald-700' : analysis.fit_score >= 55 ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'}`}>
                          {analysis.fit_score}/100
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                        <div className={`h-2 rounded-full transition-all ${analysis.fit_score >= 75 ? 'bg-emerald-500' : analysis.fit_score >= 55 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${analysis.fit_score}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* ══ FITTING TAB RESULTS ══ */}
                  {analysisType === 'fitting' && (
                    <>
                      {analysis.fitting_problems?.length > 0 && (
                        <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-4 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                            <AlertTriangle className={`w-5 h-5 ${isPremiumTheme ? 'text-amber-400' : 'text-amber-500'}`} />
                            Fitting Problems Detected
                          </h3>
                          <div className="space-y-4">
                            {analysis.fitting_problems.map((problem, i) => (
                              <div key={i} className={`p-4 rounded-xl border ${isPremiumTheme ? 'bg-slate-900/50 border-amber-500/20' : 'bg-[var(--bg-tertiary)] border-[var(--border-primary)]'}`}>
                                <div className="flex items-center gap-2 mb-2">
                                  <span className={`font-semibold ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>{problem.area}</span>
                                  <span className={`text-xs px-2 py-0.5 rounded-full border ${severityColors[problem.severity]}`}>{problem.severity}</span>
                                </div>
                                <p className={isPremiumTheme ? 'text-amber-200/70 mb-2' : 'text-[var(--text-secondary)] mb-2'}>{problem.problem}</p>
                                {problem.visual_indicator && (
                                  <p className={`text-sm mb-2 ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-tertiary)]'}`}>
                                    <span className="font-medium">What you see:</span> {problem.visual_indicator}
                                  </p>
                                )}
                                <div className={`p-3 rounded-lg border ${isPremiumTheme ? 'bg-amber-900/30 border-amber-500/30' : 'bg-violet-50 dark:bg-violet-900/20 border-violet-100 dark:border-violet-800'}`}>
                                  <p className={`text-sm font-medium ${isPremiumTheme ? 'text-amber-300' : 'text-violet-900 dark:text-violet-300'}`}>How to fix it:</p>
                                  <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/80' : 'text-violet-700 dark:text-violet-400'}`}>{problem.correction}</p>
                                  {problem.measurement_adjustment && (
                                    <p className={`text-xs mt-1 font-mono px-2 py-1 rounded inline-block ${isPremiumTheme ? 'text-amber-300 bg-amber-900/50' : 'text-violet-600 bg-violet-100 dark:bg-violet-900/40'}`}>
                                      {problem.measurement_adjustment}
                                    </p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {analysis.alteration_steps?.length > 0 && (
                        <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-4 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                            <Scissors className={`w-5 h-5 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                            Alteration Steps
                          </h3>
                          <div className="space-y-4">
                            {analysis.alteration_steps.map((step, i) => (
                              <div key={i} className="flex gap-4">
                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm ${isPremiumTheme ? 'bg-amber-900/30 text-amber-400' : 'bg-violet-100 dark:bg-violet-900/30 text-violet-600'}`}>
                                  {step.step_number || i + 1}
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <p className={`font-medium ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>{step.action}</p>
                                    <span className={`text-xs px-2 py-0.5 rounded-full ${difficultyColors[step.difficulty]}`}>{step.difficulty}</span>
                                  </div>
                                  <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>{step.details}</p>
                                  {step.tools_needed && (
                                    <p className={`text-xs mt-1 ${isPremiumTheme ? 'text-amber-200/60' : 'text-[var(--text-tertiary)]'}`}>
                                      <span className="font-medium">Tools:</span> {step.tools_needed}
                                    </p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {analysis.preventive_advice?.length > 0 && (
                        <div className={`rounded-2xl p-5 border ${isPremiumTheme ? 'bg-amber-900/10 border-amber-500/20' : 'bg-amber-50 border-amber-100'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-3 ${isPremiumTheme ? 'text-amber-300' : 'text-amber-900'}`}>
                            <Lightbulb className="w-5 h-5" />
                            Tips for Next Time
                          </h3>
                          <ul className="space-y-2">
                            {analysis.preventive_advice.map((advice, i) => (
                              <li key={i} className={`flex items-start gap-2 text-sm ${isPremiumTheme ? 'text-amber-200/80' : 'text-amber-800'}`}>
                                <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-1.5 flex-shrink-0" />
                                {advice}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  )}

                  {/* ══ SEAM QUALITY TAB RESULTS ══ */}
                  {analysisType === 'seams' && (
                    <>
                      {analysis.seam_zones?.length > 0 && (
                        <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-4 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                            <Scissors className={`w-5 h-5 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                            Zone-by-Zone Seam Check
                          </h3>
                          <div className="space-y-3">
                            {analysis.seam_zones.map((z, i) => {
                              const qualityColor = {
                                excellent: 'bg-emerald-100 text-emerald-700 border-emerald-200',
                                good: 'bg-blue-100 text-blue-700 border-blue-200',
                                needs_work: 'bg-amber-100 text-amber-700 border-amber-200',
                                poor: 'bg-rose-100 text-rose-700 border-rose-200'
                              }[z.quality] || 'bg-slate-100 text-slate-600 border-slate-200';
                              return (
                                <div key={i} className={`p-4 rounded-xl border ${isPremiumTheme ? 'bg-slate-900/50 border-amber-500/20' : 'bg-[var(--bg-tertiary)] border-[var(--border-primary)]'}`}>
                                  <div className="flex items-center justify-between mb-2">
                                    <span className={`font-semibold ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>{z.zone}</span>
                                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${qualityColor}`}>{z.quality?.replace('_', ' ')}</span>
                                  </div>
                                  <p className={`text-sm mb-2 ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>{z.verdict}</p>
                                  {z.issue && (
                                    <p className={`text-sm mb-1 ${isPremiumTheme ? 'text-rose-300/80' : 'text-rose-600'}`}>⚠ {z.issue}</p>
                                  )}
                                  {z.fix && (
                                    <div className={`mt-2 p-2.5 rounded-lg text-sm ${isPremiumTheme ? 'bg-amber-900/30 border border-amber-500/30 text-amber-200/80' : 'bg-violet-50 border border-violet-100 text-violet-700'}`}>
                                      <span className="font-medium">Fix: </span>{z.fix}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {analysis.stitching_tips?.length > 0 && (
                        <div className={`rounded-2xl p-5 border ${isPremiumTheme ? 'bg-amber-900/10 border-amber-500/20' : 'bg-amber-50 border-amber-100'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-3 ${isPremiumTheme ? 'text-amber-300' : 'text-amber-900'}`}>
                            <Lightbulb className="w-5 h-5" />
                            Stitching Tips
                          </h3>
                          <ul className="space-y-2">
                            {analysis.stitching_tips.map((tip, i) => (
                              <li key={i} className={`flex items-start gap-2 text-sm ${isPremiumTheme ? 'text-amber-200/80' : 'text-amber-800'}`}>
                                <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-1.5 flex-shrink-0" />
                                {tip}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  )}

                  {/* ══ GENERAL TAB RESULTS ══ */}
                  {analysisType === 'general' && (
                    <>
                      {analysis.fabric_assessment && (
                        <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-2 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                            <Ruler className={`w-5 h-5 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                            Fabric Assessment
                          </h3>
                          <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>{analysis.fabric_assessment}</p>
                        </div>
                      )}

                      {analysis.zone_overview?.length > 0 && (
                        <div className={`rounded-2xl p-5 shadow-lg border ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-4 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                            <Target className={`w-5 h-5 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />
                            Four-Zone Overview
                          </h3>
                          <div className="space-y-3">
                            {analysis.zone_overview.map((z, i) => {
                              const statusIcon = z.status === 'pass' ? '✅' : z.status === 'minor_issue' ? '🟡' : '🔴';
                              return (
                                <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${isPremiumTheme ? 'bg-slate-900/50 border-amber-500/20' : 'bg-[var(--bg-tertiary)] border-[var(--border-primary)]'}`}>
                                  <span className="text-lg flex-shrink-0">{statusIcon}</span>
                                  <div>
                                    <p className={`font-medium text-sm ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>{z.zone}</p>
                                    <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>{z.verdict}</p>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {(analysis.style_tip || analysis.fabric_care_tip) && (
                        <div className={`rounded-2xl p-5 border ${isPremiumTheme ? 'bg-amber-900/10 border-amber-500/20' : 'bg-amber-50 border-amber-100'}`}>
                          <h3 className={`flex items-center gap-2 font-semibold mb-3 ${isPremiumTheme ? 'text-amber-300' : 'text-amber-900'}`}>
                            <Lightbulb className="w-5 h-5" />
                            Tips for You
                          </h3>
                          {analysis.style_tip && (
                            <div className="mb-3">
                              <p className={`text-xs font-bold uppercase tracking-wide mb-1 ${isPremiumTheme ? 'text-amber-400' : 'text-amber-700'}`}>Style Tip</p>
                              <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/80' : 'text-amber-800'}`}>{analysis.style_tip}</p>
                            </div>
                          )}
                          {analysis.fabric_care_tip && (
                            <div>
                              <p className={`text-xs font-bold uppercase tracking-wide mb-1 ${isPremiumTheme ? 'text-amber-400' : 'text-amber-700'}`}>Fabric Care</p>
                              <p className={`text-sm ${isPremiumTheme ? 'text-amber-200/80' : 'text-amber-800'}`}>{analysis.fabric_care_tip}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  )}

                  {/* ── Shared: What's Working Well ── */}
                  {analysis.positive_aspects?.length > 0 && (
                    <div className={`rounded-2xl p-5 border ${isPremiumTheme ? 'bg-emerald-900/10 border-emerald-500/20' : 'bg-emerald-50 border-emerald-100'}`}>
                      <h3 className={`flex items-center gap-2 font-semibold mb-3 ${isPremiumTheme ? 'text-emerald-300' : 'text-emerald-900'}`}>
                        <CheckCircle2 className="w-5 h-5" />
                        What's Working Well
                      </h3>
                      <ul className="space-y-2">
                        {analysis.positive_aspects.map((item, i) => (
                          <li key={i} className={`flex items-start gap-2 text-sm ${isPremiumTheme ? 'text-emerald-200/80' : 'text-emerald-800'}`}>
                            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-1.5 flex-shrink-0" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* ── Shared: Coach's Note ── */}
                  {analysis.professional_notes && (
                    <div className={`rounded-2xl p-5 border ${isPremiumTheme ? 'bg-slate-900/50 border-amber-500/20' : 'bg-[var(--bg-tertiary)] border-[var(--border-primary)]'}`}>
                      <h3 className={`font-semibold mb-2 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                        {analysisType === 'seams' ? "Coach's Stitching Note" : analysisType === 'general' ? "Tailorix Verdict" : "Coach's Note"}
                      </h3>
                      <p className={`italic leading-relaxed text-sm ${isPremiumTheme ? 'text-[#E0E0E0]' : 'text-[var(--text-secondary)]'}`}>{analysis.professional_notes}</p>
                    </div>
                  )}

                  <Button onClick={clearImage} variant="outline" className="w-full rounded-2xl py-6 border-2">
                    Analyze Another Garment
                  </Button>
                </motion.div>
              )}

              {!analyzing && !analysis && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`rounded-3xl p-8 shadow-lg border text-center ${isPremiumTheme ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-amber-500/20' : 'bg-[var(--card-bg)] border-[var(--card-border)]'}`}
                >
                  <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 ${isPremiumTheme ? 'bg-amber-900/30' : 'bg-[var(--bg-tertiary)]'}`}>
                    <ImageIcon className={`w-10 h-10 ${isPremiumTheme ? 'text-amber-400' : 'text-[var(--text-tertiary)]'}`} />
                  </div>
                  <h3 className={`text-xl font-semibold mb-2 ${isPremiumTheme ? 'text-white' : 'text-[var(--text-primary)]'}`}>
                    {analysisType === 'fitting' ? 'Fitting Analysis Awaits' : analysisType === 'seams' ? 'Seam Quality Check Awaits' : 'General Overview Awaits'}
                  </h3>
                  <p className={`mb-4 ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>
                    Upload a garment photo to receive:
                  </p>
                  <ul className={`text-sm text-left space-y-2 max-w-xs mx-auto ${isPremiumTheme ? 'text-amber-200/70' : 'text-[var(--text-secondary)]'}`}>
                    {analysisType === 'fitting' && <>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Landmark-based fit diagnosis</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Exact measurements & corrections</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Step-by-step alteration guide</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Tips to avoid the same issues next time</li>
                    </>}
                    {analysisType === 'seams' && <>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Zone-by-zone seam quality rating</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Collar, sleeve, panel & hem check</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Specific stitching fixes in plain language</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Stitching tips for better results</li>
                    </>}
                    {analysisType === 'general' && <>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Garment style identification</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Fabric appearance & behaviour</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Quick four-zone overview</li>
                      <li className="flex items-center gap-2"><CheckCircle2 className={`w-4 h-4 ${isPremiumTheme ? 'text-amber-400' : 'text-violet-500'}`} />Style tip & fabric care advice</li>
                    </>}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      <UpgradeModal 
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        reason="noCredits"
        country={user?.country || 'Nigeria'}
      />

      <RateReviewModal
        trigger={reviewTrigger}
        onDismiss={resetReviewTrigger}
        isPremiumActive={isPremium}
      />
    </div>
  );
}