import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import {
  Heart, Shuffle, Sparkles, Loader2, User, ImageOff,
  MessageCircle, Share2, Scissors, Wand2, Lock, Crown,
  TrendingUp, Clock, ChevronDown, Trash2 } from
'lucide-react';
import { Button } from '@/components/ui/button';
import { usePremium } from '@/components/PremiumProvider';
import PostFullViewModal from '@/components/feed/PostFullViewModal';
import FeedSearchBar from '@/components/feed/FeedSearchBar';
import ShareMenu from '@/components/feed/ShareMenu';
import NotificationBell from '@/components/feed/NotificationBell';
import ModerationAlert from '@/components/feed/ModerationAlert';

const PAGE_SIZE = 12;

// ─── Trending Score ────────────────────────────────────────────────────────────
function trendingScore(post) {
  const ageHours = (Date.now() - new Date(post.created_date).getTime()) / (1000 * 60 * 60);
  const likes = post.likes || 0;
  const comments = post.comment_count || 0;
  const remixes = post.remix_count || 0;
  const engagement = likes * 3 + comments * 5 + remixes * 2;
  // Gravity decay: older posts score lower unless they have high engagement
  return engagement / Math.pow(ageHours + 2, 1.5);
}

// ─── Source Label ──────────────────────────────────────────────────────────────
function SourceLabel({ designType }) {
  const isPattern = designType === 'pattern';
  return isPattern ?
  <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold bg-indigo-100/90 text-indigo-700 border border-indigo-200">
      <Scissors className="w-2.5 h-2.5" /> Pattern
    </span> :

  <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold bg-rose-50 text-rose-600 border border-rose-200">
      <Wand2 className="w-2.5 h-2.5" /> Illustration
    </span>;

}

// ─── PostCard ─────────────────────────────────────────────────────────────────
function PostCard({ post, currentUser, isPremiumActive, onLike, onRemix, onOpen, onDelete, index }) {
  const [showShareMenu, setShowShareMenu] = useState(false);
  const isLiked = currentUser && (post.liked_by || []).includes(currentUser.id);

  const cardCls = isPremiumActive ?
  'bg-[#1e1e1e] border-slate-700/70' :
  'bg-[var(--card-bg)] border-[var(--card-border)]';

  const iconBtnCls = isPremiumActive ?
  'text-slate-400 hover:bg-slate-800 hover:text-slate-200' :
  'text-slate-500 hover:bg-slate-100';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.04, 0.4) }}
      className={`break-inside-avoid mb-4 rounded-2xl border overflow-hidden shadow-sm hover:shadow-lg transition-all cursor-pointer group ${cardCls}`}>
      
      {/* Image — click opens full view */}
      <div className="relative" onClick={() => onOpen(post)}>
        <img
          src={post.image_url}
          alt={post.prompt}
          className="w-full object-cover group-hover:brightness-90 transition-all"
          loading="lazy" />
        
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 text-white text-xs font-semibold px-3 py-1.5 rounded-full">
            View Details
          </span>
        </div>
        {/* Source badge top-left */}
        <div className="absolute top-2 left-2">
          <SourceLabel designType={post.design_type} />
        </div>
        {/* Stats overlay top-right */}
        






        
      </div>

      {/* Card footer */}
      <div className="px-3 pt-2 pb-2.5">
        {/* Author */}
        <div className="flex items-center gap-1.5 mb-1.5">
          <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${isPremiumActive ? 'bg-amber-500/20' : 'bg-rose-100'}`}>
            <User className={`w-2.5 h-2.5 ${isPremiumActive ? 'text-amber-400' : 'text-rose-500'}`} />
          </div>
          <span className={`text-[11px] font-medium truncate ${isPremiumActive ? 'text-slate-400' : 'text-slate-500'}`}>
            {post.user_name || 'Anonymous'}
          </span>
        </div>

        {/* Prompt snippet */}
        <p className={`text-xs line-clamp-2 leading-snug mb-2 ${isPremiumActive ? 'text-slate-300' : 'text-slate-700'}`}>
          {post.prompt}
        </p>

        {/* Action row */}
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          {/* Like */}
          <button
            onClick={() => onLike(post)}
            className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg transition-colors ${
            isLiked ? 'text-rose-500 bg-rose-50 dark:bg-rose-900/20' : iconBtnCls}`
            }>
            
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500' : ''}`} />
            {post.likes || 0}
          </button>

          {/* Comment count */}
          <button
            onClick={() => onOpen(post)}
            className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg transition-colors ${iconBtnCls}`}>
            
            <MessageCircle className="w-3.5 h-3.5" />
            {post.comment_count || 0}
          </button>

          {/* Share */}
          <button
            onClick={(e) => {e.stopPropagation();setShowShareMenu(true);}}
            className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg transition-colors ${iconBtnCls}`}>
            
            <Share2 className="w-3.5 h-3.5" />
          </button>

          {/* Remix — locked for free */}
          <div className="ml-auto flex items-center gap-1">
            {/* Delete — owner or admin only */}
            {currentUser && (currentUser.id === post.user_id || currentUser.role === 'admin') &&
            <button
              onClick={(e) => {e.stopPropagation();onDelete(post);}}
              className="p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors"
              title="Delete post">
              
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            }
            {isPremiumActive ?
            <button
              onClick={() => onRemix(post)}
              className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full font-semibold bg-gradient-to-r from-amber-500 to-yellow-500 text-black hover:opacity-90 transition-opacity">
              
                <Shuffle className="w-3 h-3" /> Remix
              </button> :

            <button
              onClick={() => onOpen(post)}
              title="Upgrade to Pro to Remix"
              className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full font-semibold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 cursor-pointer hover:bg-slate-300 transition-colors">
              
                <Lock className="w-3 h-3" />
                <Crown className="w-3 h-3 text-amber-500" />
                Remix
              </button>
            }
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showShareMenu &&
        <ShareMenu
          post={post}
          imageUrl={post.image_url}
          isPremiumActive={isPremiumActive}
          onClose={() => setShowShareMenu(false)} />

        }
      </AnimatePresence>
    </motion.div>);

}

// ─── Main Page ─────────────────────────────────────────────────────────────────
export default function InspirationFeed() {
  const navigate = useNavigate();
  const { user: currentUser, isPremiumActive } = usePremium();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPost, setSelectedPost] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);
  const searchTimeoutRef = React.useRef(null);
  const [sortMode, setSortMode] = useState('trending'); // 'trending' | 'recent'
  const [page, setPage] = useState(1);
  const [moderationMsg, setModerationMsg] = useState(null);

  // Auto-open post from notification redirect
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const openPostId = params.get('open_post');
    if (openPostId && posts.length > 0) {
      const found = posts.find((p) => p.id === openPostId);
      if (found) setSelectedPost(found);
    }
  }, [posts]);

  useEffect(() => {
    loadPosts();

    // Real-time: InspirationPost changes (likes, comment_count, new posts, deletes)
    const unsubPost = base44.entities.InspirationPost.subscribe((event) => {
      if (event.type === 'update') {
        setPosts((prev) => prev.map((p) => p.id === event.id ? { ...p, ...event.data } : p));
        setSelectedPost((prev) => prev && prev.id === event.id ? { ...prev, ...event.data } : prev);
      } else if (event.type === 'create' && event.data) {
        setPosts((prev) => {
          if (prev.some((p) => p.id === event.id)) return prev;
          return [{ ...event.data, comment_count: 0 }, ...prev];
        });
      } else if (event.type === 'delete') {
        setPosts((prev) => prev.filter((p) => p.id !== event.id));
      }
    });

    // Real-time: DesignComment creates → increment comment_count on the relevant card immediately
    const unsubComment = base44.entities.DesignComment.subscribe((event) => {
      if (event.type === 'create' && event.data?.design_id) {
        setPosts((prev) => prev.map((p) =>
        p.id === event.data.design_id ?
        { ...p, comment_count: (p.comment_count || 0) + 1 } :
        p
        ));
      } else if (event.type === 'delete' && event.data?.design_id) {
        setPosts((prev) => prev.map((p) =>
        p.id === event.data.design_id ?
        { ...p, comment_count: Math.max(0, (p.comment_count || 1) - 1) } :
        p
        ));
      }
    });

    return () => {unsubPost();unsubComment();};
  }, []);

  const loadPosts = async () => {
    setLoading(true);
    try {
      const [data, allComments] = await Promise.all([
      base44.entities.InspirationPost.list('-created_date', 100),
      base44.entities.DesignComment.list('-created_date', 500)]
      );

      // Count comments per post from actual DesignComment records
      const countMap = {};
      allComments.forEach((c) => {
        countMap[c.design_id] = (countMap[c.design_id] || 0) + 1 + (c.replies?.length || 0);
      });

      // Merge accurate counts into posts; persist any that differ from stored value
      const postsWithCounts = data.map((p) => {
        const realCount = countMap[p.id] || 0;
        if (p.comment_count !== realCount) {
          base44.entities.InspirationPost.update(p.id, { comment_count: realCount }).catch(() => {});
        }
        return { ...p, comment_count: realCount };
      });

      setPosts(postsWithCounts);
    } catch (e) {console.error(e);}
    setLoading(false);
  };

  // ── Create a notification for the post owner ─────────────────────────────
  const createNotification = useCallback(async (post, type) => {
    if (!currentUser) return;
    if (post.user_id === currentUser.id) return; // don't notify yourself
    base44.entities.Notification.create({
      recipient_id: post.user_id,
      actor_name: currentUser.full_name || 'Someone',
      actor_id: currentUser.id,
      type,
      post_id: post.id,
      post_preview: (post.prompt || '').substring(0, 60),
      post_image_url: post.image_url || '',
      is_read: false
    }).catch(() => {});
  }, [currentUser]);

  const handleLike = useCallback(async (post) => {
    if (!currentUser) return;
    const alreadyLiked = (post.liked_by || []).includes(currentUser.id);
    const newLikedBy = alreadyLiked ?
    (post.liked_by || []).filter((id) => id !== currentUser.id) :
    [...(post.liked_by || []), currentUser.id];
    const newLikes = newLikedBy.length;
    const updated = { ...post, liked_by: newLikedBy, likes: newLikes };
    setPosts((prev) => prev.map((p) => p.id === post.id ? updated : p));
    if (selectedPost?.id === post.id) setSelectedPost(updated);
    try {
      await base44.entities.InspirationPost.update(post.id, { liked_by: newLikedBy, likes: newLikes });
      if (!alreadyLiked) createNotification(post, 'like');
    } catch (e) {console.error(e);loadPosts();}
  }, [currentUser, selectedPost, createNotification]);

  const handleDelete = useCallback(async (post) => {
    if (!currentUser) return;
    if (currentUser.id !== post.user_id && currentUser.role !== 'admin') return;
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    setPosts((prev) => prev.filter((p) => p.id !== post.id));
    if (selectedPost?.id === post.id) setSelectedPost(null);
    base44.entities.InspirationPost.delete(post.id).catch(console.error);
  }, [currentUser, selectedPost]);

  const handleRemix = useCallback(async (post) => {
    if (!isPremiumActive) return; // gate
    try {
      await base44.entities.InspirationPost.update(post.id, { remix_count: (post.remix_count || 0) + 1 });
      createNotification(post, 'remix');
    } catch (e) {console.error(e);}
    // Land on Modify tab with the post image and prompt pre-populated
    const params = new URLSearchParams({
      remix_tab: 'modify',
      remix_image_url: post.image_url || '',
      remix_prompt: post.prompt || '',
      remix_body_type: post.body_type || '',
      remix_fabric_type: post.fabric_type || '',
      remix_occasion: post.occasion || ''
    });
    navigate(`/DesignGenerator?${params.toString()}`);
  }, [isPremiumActive, navigate]);

  // ── Derived: filter + sort + paginate ─────────────────────────────────────
  const filteredSorted = useMemo(() => {
    let list = [...posts];

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter((p) =>
      (p.user_name || '').toLowerCase().includes(q) ||
      (p.prompt || '').toLowerCase().includes(q) ||
      (p.fabric_type || '').toLowerCase().includes(q) ||
      (p.occasion || '').toLowerCase().includes(q) ||
      (p.body_type || '').toLowerCase().includes(q)
      );
    }

    // Sort
    if (sortMode === 'trending') {
      list.sort((a, b) => trendingScore(b) - trendingScore(a));
    } else {
      list.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }

    return list;
  }, [posts, searchQuery, sortMode]);

  const visiblePosts = filteredSorted.slice(0, page * PAGE_SIZE);
  const hasMore = visiblePosts.length < filteredSorted.length;

  const badgeCls = isPremiumActive ?
  'bg-amber-500/10 border border-amber-500/30 text-amber-400' :
  'bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400';

  const ctaBtnCls = isPremiumActive ?
  'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-bold border-none' :
  'bg-rose-500 hover:bg-rose-600 text-white';

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isPremiumActive ? 'bg-[#121212]' : 'bg-[var(--bg-primary)]'}`}>
        <Loader2 className={`w-10 h-10 animate-spin ${isPremiumActive ? 'text-amber-400' : 'text-rose-500'}`} />
      </div>);

  }

  return (
    <div className={`min-h-screen py-8 px-4 ${isPremiumActive ? 'bg-[#121212]' : 'bg-[var(--bg-primary)]'}`}>
      <div className="max-w-5xl mx-auto">

        {/* ── Header ── */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <div />
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${badgeCls}`}>
              <Sparkles className="w-4 h-4" />
              Community Designs
            </div>
            {/* Notification Bell */}
            <NotificationBell
              currentUser={currentUser}
              isPremiumActive={isPremiumActive}
              onOpenPost={(postId) => {
                const found = posts.find((p) => p.id === postId);
                if (found) setSelectedPost(found);
              }} />
            
          </div>
          <div className="text-center">
            <h1 className={`text-3xl md:text-4xl font-bold mb-2 ${isPremiumActive ? 'text-white' : 'text-[var(--text-primary)]'}`}>
              Inspiration Feed
            </h1>
            <p className={`max-w-xl mx-auto text-sm ${isPremiumActive ? 'text-slate-400' : 'text-[var(--text-secondary)]'}`}>
              Browse AI-generated designs & patterns. Like, comment, remix, or download what inspires you.
            </p>
          </div>
        </motion.div>

        {/* ── Search + Sort Controls ── */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="flex flex-col sm:flex-row items-center gap-3 mb-6">
          <FeedSearchBar
            value={searchInput}
            onChange={(v) => {
              setSearchInput(v);
              setPage(1);
              if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
              if (!v.trim()) {setSearchQuery('');setSearchLoading(false);return;}
              setSearchLoading(true);
              searchTimeoutRef.current = setTimeout(() => {
                setSearchQuery(v);
                setSearchLoading(false);
              }, 300);
            }}
            isPremiumActive={isPremiumActive}
            isSearching={searchLoading} />
          

          {/* Sort toggle */}
          <div className={`flex items-center rounded-full p-1 flex-shrink-0 ${isPremiumActive ? 'bg-slate-800' : 'bg-slate-100'}`}>
            <button
              onClick={() => {setSortMode('trending');setPage(1);}}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              sortMode === 'trending' ?
              isPremiumActive ? 'bg-amber-500 text-black' : 'bg-rose-500 text-white' :
              isPremiumActive ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-700'}`
              }>
              
              <TrendingUp className="w-3.5 h-3.5" /> Trending
            </button>
            <button
              onClick={() => {setSortMode('recent');setPage(1);}}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              sortMode === 'recent' ?
              isPremiumActive ? 'bg-amber-500 text-black' : 'bg-rose-500 text-white' :
              isPremiumActive ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-700'}`
              }>
              
              <Clock className="w-3.5 h-3.5" /> Recent
            </button>
          </div>
        </motion.div>

        {/* ── Grid ── */}
        {filteredSorted.length === 0 ?
        <div className="flex flex-col items-center justify-center py-24 text-center">
            <ImageOff className={`w-16 h-16 mb-4 ${isPremiumActive ? 'text-slate-600' : 'text-[var(--text-tertiary)]'}`} />
            {searchQuery ?
          <>
                <h3 className={`text-xl font-semibold mb-2 ${isPremiumActive ? 'text-white' : 'text-[var(--text-primary)]'}`}>No results found</h3>
                <p className={`mb-4 ${isPremiumActive ? 'text-slate-400' : 'text-[var(--text-secondary)]'}`}>
                  Try searching for something else.
                </p>
                <Button variant="outline" onClick={() => setSearchQuery('')}>Clear Search</Button>
              </> :

          <>
                <h3 className={`text-xl font-semibold mb-2 ${isPremiumActive ? 'text-white' : 'text-[var(--text-primary)]'}`}>No posts yet</h3>
                <p className={`mb-6 ${isPremiumActive ? 'text-slate-400' : 'text-[var(--text-secondary)]'}`}>Be the first to share your design!</p>
                <Button
              onClick={() => navigate(createPageUrl(isPremiumActive ? 'DesignGenerator' : 'FreeDesignIllustrator'))}
              className={`rounded-xl ${ctaBtnCls}`}>
              
                  <Sparkles className="w-4 h-4 mr-2" /> Create a Design
                </Button>
              </>
          }
          </div> :

        <>
            <div className="columns-2 md:columns-3 gap-4">
              <AnimatePresence>
                {visiblePosts.map((post, i) =>
              <PostCard
                key={post.id}
                post={post}
                currentUser={currentUser}
                isPremiumActive={isPremiumActive}
                onLike={handleLike}
                onRemix={handleRemix}
                onOpen={setSelectedPost}
                onDelete={handleDelete}
                index={i} />

              )}
              </AnimatePresence>
            </div>

            {/* ── See More ── */}
            {hasMore &&
          <div className="flex justify-center mt-8">
                <Button
              variant="outline"
              onClick={() => setPage((p) => p + 1)}
              className={`rounded-full px-8 gap-2 ${isPremiumActive ? 'border-slate-700 text-slate-300 hover:bg-slate-800' : ''}`}>
              
                  <ChevronDown className="w-4 h-4" />
                  See More ({filteredSorted.length - visiblePosts.length} remaining)
                </Button>
              </div>
          }
          </>
        }
      </div>

      {/* ── Full View Modal ── */}
      <AnimatePresence>
        {selectedPost &&
        <PostFullViewModal
          post={selectedPost}
          currentUser={currentUser}
          isPremiumActive={isPremiumActive}
          onClose={() => setSelectedPost(null)}
          onLike={handleLike}
          onRemix={handleRemix}
          onDelete={handleDelete}
          onCommentPosted={(post) => createNotification(post, 'comment')}
          onCommentCountChange={(postId, newCount) => {
            setPosts((prev) => prev.map((p) => p.id === postId ? { ...p, comment_count: newCount } : p));
            setSelectedPost((prev) => prev && prev.id === postId ? { ...prev, comment_count: newCount } : prev);
          }} />

        }
      </AnimatePresence>

      {/* ── Moderation Alert ── */}
      <ModerationAlert message={moderationMsg} onClose={() => setModerationMsg(null)} />
    </div>);

}