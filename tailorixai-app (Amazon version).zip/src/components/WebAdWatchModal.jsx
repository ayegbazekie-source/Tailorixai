import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Loader2, Play, Clock, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import CreditAddedModal from '@/components/CreditAddedModal';

const MAX_ADS_PER_DAY = 5;
const AD_URL = 'https://omg10.com/4/10804562';
const COUNTDOWN_SECONDS = 30;

// Loud success chime via Web Audio API
function playSuccessSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();

    const playNote = (freq, startTime, duration) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.8, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };

    const t = ctx.currentTime;
    playNote(660, t, 0.15);
    playNote(880, t + 0.15, 0.15);
    playNote(1100, t + 0.3, 0.4);
  } catch (_) {}
}

export default function WebAdWatchModal({ isOpen, onClose, onReward }) {
  const [stage, setStage] = useState('ready'); // ready | watching | processing | error | limit
  const [countdown, setCountdown] = useState(COUNTDOWN_SECONDS);
  const [adsWatched, setAdsWatched] = useState(0);
  const [configLoading, setConfigLoading] = useState(true);
  const [showFocusWarning, setShowFocusWarning] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const countdownRef = useRef(null);
  const focusWarningRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setStage('ready');
      setCountdown(COUNTDOWN_SECONDS);
      setShowFocusWarning(false);
      setShowSuccessModal(false);
      loadUserData();
    }
    return () => {
      clearInterval(countdownRef.current);
      clearTimeout(focusWarningRef.current);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isOpen]);

  const loadUserData = async () => {
    setConfigLoading(true);
    try {
      const userRes = await base44.auth.me();
      setAdsWatched(userRes?.rewarded_ads_watched_today || 0);
    } catch (_) {}
    setConfigLoading(false);
  };

  const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible') {
      setShowFocusWarning(true);
      clearTimeout(focusWarningRef.current);
      focusWarningRef.current = setTimeout(() => setShowFocusWarning(false), 5000);
    }
  };

  const handleWatchAd = () => {
    if (adsWatched >= MAX_ADS_PER_DAY) {
      setStage('limit');
      return;
    }

    window.open(AD_URL, '_blank');
    setStage('watching');
    setCountdown(COUNTDOWN_SECONDS);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    let remaining = COUNTDOWN_SECONDS;
    countdownRef.current = setInterval(() => {
      remaining -= 1;
      setCountdown(remaining);
      if (remaining <= 0) {
        clearInterval(countdownRef.current);
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        grantReward();
      }
    }, 1000);
  };

  const grantReward = async () => {
    setStage('processing');
    try {
      const result = await onReward();
      if (result?.success || result?.isPremium) {
        const newCount = adsWatched + 1;
        setAdsWatched(newCount);
        playSuccessSound();
        setStage('ready');
        setShowSuccessModal(true);
      } else if (result?.error?.includes('limit')) {
        setStage('limit');
      } else {
        setStage('error');
      }
    } catch {
      setStage('error');
    }
  };

  const handleSuccessClose = () => {
    setShowSuccessModal(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-[var(--card-bg)] rounded-3xl p-8 max-w-md w-full shadow-2xl"
          >

            {/* READY */}
            {stage === 'ready' && (
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
                  <Play className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-2">Watch Ad → +1 Credit</h2>
                <p className="text-[var(--text-secondary)] mb-1">An ad will open in a new tab. Stay on it for 30 seconds to earn your credit.</p>
                <p className="text-sm text-[var(--text-secondary)] mb-6">
                  {configLoading ? '...' : `${adsWatched} / ${MAX_ADS_PER_DAY} ads watched today`}
                </p>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">Cancel</Button>
                  <Button
                    onClick={handleWatchAd}
                    disabled={configLoading || adsWatched >= MAX_ADS_PER_DAY}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white rounded-xl"
                  >
                    {configLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Watch Ad'}
                  </Button>
                </div>
              </div>
            )}

            {/* WATCHING */}
            {stage === 'watching' && (
              <div className="text-center py-2">
                <AnimatePresence>
                  {showFocusWarning && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mb-4 px-4 py-3 bg-amber-100 dark:bg-amber-900/40 border border-amber-300 dark:border-amber-700 rounded-2xl flex items-center gap-2 text-amber-800 dark:text-amber-300 text-sm font-medium"
                    >
                      <Eye className="w-4 h-4 flex-shrink-0" />
                      Ad still playing! Please stay on the ad tab for the full 30s to earn your credit.
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="relative w-32 h-32 mx-auto mb-6">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="44" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-200 dark:text-slate-700" />
                    <circle
                      cx="50" cy="50" r="44" fill="none" stroke="currentColor" strokeWidth="8"
                      className="text-blue-500"
                      strokeDasharray={`${2 * Math.PI * 44}`}
                      strokeDashoffset={`${2 * Math.PI * 44 * (countdown / COUNTDOWN_SECONDS)}`}
                      style={{ transition: 'stroke-dashoffset 1s linear' }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-4xl font-bold text-[var(--text-primary)]">{countdown}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-1">Verifying View ({countdown}s)...</h3>
                <p className="text-[var(--text-secondary)] text-sm">Keep the ad tab open. Credit is awarded after 30 seconds.</p>
              </div>
            )}

            {/* PROCESSING */}
            {stage === 'processing' && (
              <div className="text-center py-10">
                <Loader2 className="w-16 h-16 animate-spin text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-[var(--text-primary)]">Awarding credit...</h3>
              </div>
            )}

            {/* LIMIT */}
            {stage === 'limit' && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-10 h-10 text-amber-500" />
                </div>
                <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">Daily Limit Reached</h3>
                <p className="text-[var(--text-secondary)] mb-6">You've watched {MAX_ADS_PER_DAY}/{MAX_ADS_PER_DAY} ads today. Come back tomorrow!</p>
                <Button onClick={onClose} variant="outline" className="rounded-xl">Close</Button>
              </div>
            )}

            {/* ERROR */}
            {stage === 'error' && (
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <X className="w-10 h-10 text-red-500" />
                </div>
                <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">Something Went Wrong</h3>
                <p className="text-[var(--text-secondary)] mb-6">Could not process your reward. Please try again.</p>
                <Button onClick={onClose} variant="outline" className="rounded-xl">Close</Button>
              </div>
            )}

          </motion.div>
        </motion.div>
      </AnimatePresence>

      {/* Success popup — renders on top of everything */}
      <CreditAddedModal
        isOpen={showSuccessModal}
        onClose={handleSuccessClose}
        adsWatched={adsWatched}
        maxAds={MAX_ADS_PER_DAY}
      />
    </>
  );
}