/**
 * AmazonIAPHandler
 *
 * Listens for IAP purchase callbacks injected by the Amazon WebView native wrapper.
 * The wrapper calls window.__onAmazonPurchaseSuccess({ receiptId, amazonUserId })
 * after a successful purchase.
 *
 * Usage: Mount once at the top of the app (e.g. inside PremiumProvider or Layout).
 * It calls verifyAmazonPurchase backend function, then refreshes premium status.
 */

import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { IS_AMAZON } from '@/lib/platform';

export default function AmazonIAPHandler({ onPurchaseSuccess }) {
  useEffect(() => {
    if (!IS_AMAZON) return;

    // Native wrapper calls this global after a successful IAP
    window.__onAmazonPurchaseSuccess = async ({ receiptId, amazonUserId }) => {
      try {
        const res = await base44.functions.invoke('verifyAmazonPurchase', { receiptId, amazonUserId });
        if (res.data?.success && onPurchaseSuccess) {
          onPurchaseSuccess();
        }
      } catch (e) {
        console.error('Amazon IAP verification failed:', e);
      }
    };

    // Native wrapper calls this if user cancels or billing fails
    window.__onAmazonPurchaseFailed = (reason) => {
      console.warn('Amazon IAP failed:', reason);
    };

    return () => {
      delete window.__onAmazonPurchaseSuccess;
      delete window.__onAmazonPurchaseFailed;
    };
  }, [onPurchaseSuccess]);

  return null; // No UI — just a side-effect handler
}