import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let adConfig = {
      provider: 'monetag',
      adEnabled: true,
      monetagScript: ''
    };

    try {
      const configs = await base44.asServiceRole.entities.AppConfig.filter({ key: 'web_ad_config' });
      if (configs && configs.length > 0) {
        adConfig = JSON.parse(configs[0].value);
      }
    } catch (_) {}

    return Response.json(adConfig);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});