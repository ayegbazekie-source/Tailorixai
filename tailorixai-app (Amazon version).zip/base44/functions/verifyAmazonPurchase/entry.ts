import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

/**
 * Amazon In-App Purchase Verification
 *
 * Amazon RVS (Receipt Verification Service) endpoint.
 * The Amazon WebView native wrapper calls this after a successful IAP.
 *
 * Flow:
 *  1. Native Amazon app triggers IAP dialog
 *  2. On success, native layer calls this function with { receiptId, userId }
 *  3. This verifies with Amazon RVS and grants isPro = true
 *
 * IS_PRODUCTION = 'false' → DEV MODE: simulates successful purchase
 * IS_PRODUCTION = 'true'  → PROD MODE: verifies with Amazon RVS
 */

const AMAZON_APP_ID = Deno.env.get('AMAZON_APP_ID') || '';
const AMAZON_SKU = Deno.env.get('AMAZON_SKU') || '';
const AMAZON_PUBLIC_KEY = Deno.env.get('AMAZON_PUBLIC_KEY') || '';
const IS_PRODUCTION = Deno.env.get('IS_PRODUCTION') === 'true';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // ── DEV / SIMULATION MODE ─────────────────────────────────────────────────
    if (!IS_PRODUCTION) {
      const premiumExpiry = new Date();
      premiumExpiry.setDate(premiumExpiry.getDate() + 92); // 3 months

      await base44.auth.updateMe({
        isPro: true,
        is_premium: true,
        premium_expiry_date: premiumExpiry.toISOString().split('T')[0],
        subscription_source: 'amazon_simulated',
        amazon_trial_start: new Date().toISOString().split('T')[0],
        last_credit_reset_date: new Date().toISOString().split('T')[0]
      });

      return Response.json({
        success: true,
        mode: 'development',
        simulated: true,
        message: 'DEV: Simulated Amazon IAP. isPro set to true.',
        sku: AMAZON_SKU || 'com.tailorix.pro.monthly'
      });
    }

    // ── PRODUCTION MODE: Verify with Amazon RVS ───────────────────────────────
    const body = await req.json().catch(() => ({}));
    const { receiptId, amazonUserId } = body;

    if (!receiptId || !amazonUserId) {
      return Response.json({
        error: 'receiptId and amazonUserId are required in production mode',
        hint: 'Pass these from the Amazon IAP SDK onPurchaseSucceeded callback'
      }, { status: 400 });
    }

    if (!AMAZON_PUBLIC_KEY) {
      return Response.json({
        error: 'AMAZON_PUBLIC_KEY secret not set. Add it in dashboard settings.',
      }, { status: 500 });
    }

    // Verify with Amazon Receipt Verification Service (RVS)
    const rvsUrl = `https://appstore-sdk.amazon.com/version/1.0/verifyReceiptId/developer/${AMAZON_PUBLIC_KEY}/user/${amazonUserId}/receiptId/${receiptId}`;
    const rvsRes = await fetch(rvsUrl, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    const rvsData = await rvsRes.json();

    if (!rvsRes.ok || rvsData.status !== 0) {
      return Response.json({
        success: false,
        error: 'Amazon receipt verification failed',
        rvsStatus: rvsData.status,
        details: rvsData
      }, { status: 400 });
    }

    const receiptInfo = rvsData.receiptInfo;

    // Check it's the right SKU
    if (receiptInfo?.productId !== AMAZON_SKU && AMAZON_SKU) {
      return Response.json({
        success: false,
        error: 'SKU mismatch',
        expected: AMAZON_SKU,
        received: receiptInfo?.productId
      }, { status: 400 });
    }

    // Check cancellation — cancelDate present and in the past means cancelled
    if (receiptInfo?.cancelDate) {
      const cancelDate = new Date(receiptInfo.cancelDate);
      if (cancelDate < new Date()) {
        return Response.json({ success: false, error: 'Subscription has been cancelled' }, { status: 400 });
      }
    }

    // Grant premium — 3-month (92-day) recurring subscription with 7-day free trial
    const premiumExpiry = new Date();
    premiumExpiry.setDate(premiumExpiry.getDate() + 92);

    await base44.auth.updateMe({
      isPro: true,
      is_premium: true,
      premium_expiry_date: premiumExpiry.toISOString().split('T')[0],
      subscription_source: 'amazon_verified',
      amazon_receipt_id: receiptId,
      amazon_user_id: amazonUserId,
      amazon_trial_start: new Date().toISOString().split('T')[0],
      last_credit_reset_date: new Date().toISOString().split('T')[0]
    });

    return Response.json({
      success: true,
      mode: 'production',
      verified: true,
      sku: receiptInfo?.productId,
      purchaseDate: receiptInfo?.purchaseDate,
      expiresAt: premiumExpiry.toISOString().split('T')[0],
      message: 'Amazon IAP verified and premium activated.'
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});