/**
 * Serves /app-ads.txt for Google to verify ad publisher ownership.
 * Publisher ID: pub-9053391149127134
 * Required for authorized sellers verification and high-paying ads.
 *
 * Deploy this function and set its public route to /app-ads.txt
 * in the Base44 dashboard (or configure your reverse proxy/CDN to
 * serve /app-ads.txt from this endpoint).
 */
Deno.serve(async (_req) => {
  const content = `google.com, pub-9053391149127134, DIRECT, f08c47fec0942fa0`;

  return new Response(content, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=86400',
    },
  });
});