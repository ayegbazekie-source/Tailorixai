import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const config = await req.json();

    const allowed = ['monetag', 'disabled'];
    if (!allowed.includes(config.provider)) {
      return Response.json({ error: 'Invalid provider' }, { status: 400 });
    }

    const valueStr = JSON.stringify({
      provider: config.provider,
      adEnabled: !!config.adEnabled,
      monetagScript: config.monetagScript || ''
    });

    const existing = await base44.asServiceRole.entities.AppConfig.filter({ key: 'web_ad_config' });
    if (existing && existing.length > 0) {
      await base44.asServiceRole.entities.AppConfig.update(existing[0].id, { value: valueStr });
    } else {
      await base44.asServiceRole.entities.AppConfig.create({
        key: 'web_ad_config',
        value: valueStr,
        description: 'Web ad provider configuration (JSON)'
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});