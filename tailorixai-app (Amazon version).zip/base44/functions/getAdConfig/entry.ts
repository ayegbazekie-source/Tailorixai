import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Google's official test ad unit IDs — safe for dev
const TEST_REWARDED_ID = 'ca-app-pub-3940256099942544/5224354917';
const TEST_INTERSTITIAL_ID = 'ca-app-pub-3940256099942544/1033173712';
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/6300978111';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // 1. Try to read is_production from database (AppConfig entity)
    let isProduction = false;
    try {
      const configs = await base44.asServiceRole.entities.AppConfig.filter({ key: 'is_production' });
      if (configs && configs.length > 0) {
        isProduction = configs[0].value === 'true';
      } else {
        // 2. Fall back to environment variable if no DB record exists
        isProduction = Deno.env.get('IS_PRODUCTION') === 'true';
      }
    } catch (_dbErr) {
      // 3. If DB unreachable, fall back to env var; if also missing, default false
      isProduction = Deno.env.get('IS_PRODUCTION') === 'true';
    }

    // Read google_play_sub_id from DB, fall back to secret
    let googlePlaySubId = '';
    try {
      const subConfigs = await base44.asServiceRole.entities.AppConfig.filter({ key: 'google_play_sub_id' });
      if (subConfigs && subConfigs.length > 0 && subConfigs[0].value) {
        googlePlaySubId = subConfigs[0].value;
      }
    } catch (_) {}
    if (!googlePlaySubId) {
      googlePlaySubId = Deno.env.get('GOOGLE_PLAY_SUB_ID') || '';
    }

    const adUnitId = isProduction ? (Deno.env.get('ADMOB_REWARDED_ID') || '') : TEST_REWARDED_ID;

    return Response.json({
      adUnitId,
      isProduction,
      testMode: !isProduction,
      admobAppId: Deno.env.get('ADMOB_APP_ID') || '',
      googlePlaySubId,
      interstitialAdUnitId: isProduction ? (Deno.env.get('ADMOB_INTERSTITIAL_ID') || '') : TEST_INTERSTITIAL_ID,
      bannerAdUnitId: isProduction ? (Deno.env.get('ADMOB_BANNER_ID') || '') : TEST_BANNER_ID
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});